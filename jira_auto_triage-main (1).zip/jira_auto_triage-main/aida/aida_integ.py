import os
import pickle
import time
import json
import warnings
import re
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Suppress specific warnings
warnings.filterwarnings("ignore", category=DeprecationWarning)

# Function to save cookies to a file after login
def save_cookies(driver, path='cookies.pkl'):
    with open(path, 'wb') as filehandler:
        pickle.dump(driver.get_cookies(), filehandler)
    print("Cookies saved.")

# Function to load cookies from file and add them to the driver
def load_cookies(driver, path='cookies.pkl'):
    try:
        with open(path, 'rb') as cookiesfile:
            cookies = pickle.load(cookiesfile)
            print("Loaded cookies:", cookies)
            driver.get("https://aida.amd.com")
            for cookie in cookies:
                if 'domain' in cookie:
                    del cookie['domain']
                if 'expiry' in cookie:
                    del cookie['expiry']
                driver.add_cookie(cookie)
    except Exception as e:
        print(f"Could not load cookies: {e}")

# Function to log in to AIDA
def login_to_aida(driver, username, password):
    driver.get("https://aida.amd.com/ui/login?redirectTo=/autodebug")
    WebDriverWait(driver, 30).until(
        EC.presence_of_element_located((By.XPATH, "//input[@name='username']")) 
    )
    driver.find_element(By.XPATH, "//input[@name='username']").send_keys(username)  
    driver.find_element(By.XPATH, "//input[@name='password']").send_keys(password)  
    driver.find_element(By.XPATH, "//button[@type='submit']").click()  
    print("Login submitted.")

# Function to ensure we are logged in to AIDA (if cookies exist, load them; otherwise log in manually)
def ensure_logged_in(driver, username, password):
    cookies_file = 'cookies.pkl'
    # Check if cookies file exists and has valid content
    if os.path.exists(cookies_file):
        try:
            with open(cookies_file, 'rb') as f:
                cookies = pickle.load(f)
            if cookies and len(cookies) > 0:
                print("Loading saved cookies to bypass login.")
                load_cookies(driver, cookies_file)
                driver.get("https://aida.amd.com/autodebug")
                time.sleep(5)  # wait for any login refresh
                print("Cookies loaded and refreshed.")
                return
            else:
                print("Cookies file is empty. Proceeding with full login.")
                os.remove(cookies_file)
        except Exception as e:
            print(f"Error reading cookies file: {e}")
    # If no valid cookies exist, log in manually
    login_to_aida(driver, username, password)
    time.sleep(5)  # wait for login to complete
    save_cookies(driver, cookies_file)
    driver.get("https://aida.amd.com/autodebug")
    time.sleep(5)  # wait for login to settle
    print("Logged in and cookies saved.")

# Function to read data from AIDA and extract necessary information
def read_data_from_aida(url, username, password):
    options = webdriver.ChromeOptions()
    # For debugging, comment out headless (remove the below line) so you can see the browser
    options.add_argument('--headless')
    options.add_argument('--no-sandbox')
    options.add_argument('--disable-dev-shm-usage')
    options.add_argument('--disable-gpu')
    driver = webdriver.Chrome(options=options)

    ensure_logged_in(driver, username, password)
    driver.get(url)

    try:
        WebDriverWait(driver, 40).until(
            EC.presence_of_element_located((By.XPATH, "//strong[string()='Explanation:']"))
        )
    except Exception as e:
        print(f"Exception occurred while waiting for the page to load: {e}")
        with open("debug_page.html", "w", encoding="utf-8") as f:
            f.write(driver.page_source)
        driver.save_screenshot("debug_screenshot.png")
        driver.quit()
        return None

    time.sleep(2)
    soup = BeautifulSoup(driver.page_source, 'html.parser')
    driver.quit()

    # Extract fields
    data = {
        'summary': '',
        'description': '',
        'triage_assignment': '',
        'triage_category': '',
    }

    summary_header = soup.find('strong', string=re.compile(r'(Executive Summary|Summary)', re.IGNORECASE))
    explanation_header = soup.find('strong', string='Explanation:')
    # print("Summary header found:", summary_header)
    if summary_header:
        try:
            # 1) Check if the heading is inside a <p>. If so, grab that text.
            parent_p = summary_header.find_parent('p')
            summary_text = ""
            if parent_p:
                p_text = parent_p.get_text(strip=True)
                # Remove the header text
                p_text = re.sub(r'^(Executive Summary:|Summary:)\s*', '', p_text, flags=re.IGNORECASE).strip()
                if p_text:
                    summary_text = p_text
                else:
                    # If nothing remains, use the next <p> as a fallback.
                    next_p = parent_p.find_next_sibling('p')
                    summary_text = next_p.get_text(strip=True) if next_p else ""
            else:
                # If no parent <p>, look for the next <p> after header.
                next_p = summary_header.find_next('p')
                summary_text = next_p.get_text(strip=True) if next_p else ""
            data['summary'] = summary_text
            # print(f"Summary: {summary_text}")
            # 3) Shorten to the first sentence
            first_period_index = summary_text.find('.')
            if first_period_index != -1:
                data['summary'] = summary_text[:first_period_index + 1].strip()
                # print("Summary short:" + data['summary'] + "\n")
            else:
                data['summary'] = summary_text
        except Exception as e:
            print(f"Error extracting summary: {e}")
    else:
        print("Summary element not found.")

    if explanation_header:
        try:
            explanation_text = explanation_header.find_next('ol').get_text(strip=True)
            data['description'] = explanation_text
            #print(f"Description: {explanation_text}")
        except Exception as e:
            print(f"Error extracting explanation: {e}")
    else:
        print("Explanation element not found.")

    return data

def save_data_as_json(data, filename):
    with open(filename, 'w') as json_file:
        json.dump(data, json_file, indent=4)

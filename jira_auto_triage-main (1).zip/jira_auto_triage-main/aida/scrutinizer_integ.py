import requests
from requests.auth import HTTPBasicAuth
from lxml import html
from selenium import webdriver
from selenium.webdriver.common.by import By
import time

def read_scrutinizer_data(url):
    response = requests.get(url, timeout=10)

    # Parse the response content using lxml
    tree = html.fromstring(response.content)
    data = {}
    
    program = tree.xpath("//tr[td/b[text()='Program']]/td[2]/text()")
    bios = tree.xpath("//tr[td/b[text()='BIOS']]/td[2]/text()")
    revision = tree.xpath("//tr[td/b[text()='Revision']]/td[2]/text()")
    steps_to_reproduce = tree.xpath("//tr[td/b[text()='Queue']]/td[2]/text()")
    platform = tree.xpath("//tr[td/b[text()='Platform']]/td[2]//a/text()")
    # failure_type = tree.xpath("//tr[td/b[text()='Failure Type']]/td[2]/text()")
    ads = tree.xpath("//tr[td/b[text()='ADS FailureAnalysis URL']]/td[2]//a/text()")
    test_name = tree.xpath("//tr[td/b[text()='Test Name']]/td[2]//a/text()")
    amdz_link = tree.xpath("//a[contains(@href, 'amdz.xml')]/@href")
   
    if program:
        data['program']= program[0].strip()
        if data['program'] == 'Hawkpoint1':
            data['program'] = 'Hawk Point 1'
        elif data['program'] == 'Hawkpoint2':   
            data['program'] = 'Hawk Point 2'
    if bios:
        data['bios'] = bios[0].strip()
    if revision:
        data['revision'] = revision[0].strip()
    if steps_to_reproduce:
        data['steps_to_reproduce'] = steps_to_reproduce[0].strip()
    # if failure_type:
    #     data['summary'] = data['steps_to_reproduce'] + ', ' + failure_type[0].strip()
    if ads:
        data['description'] = f"ADS Failure Analysis URL: {ads[0].strip()}"
    if amdz_link:
        data['description'] += f"\nAMDZ: http://scrutinizer.amd.com/{amdz_link[0]}"
    if test_name:
        data['summary'] = test_name[0].strip()
        loops = tree.xpath("//tr[td/b[text()='Loops']]/td[2]/text()")
        loop_count = loops[0].strip()
        if 'Standby' or 'S4' or 'S5' in test_name[0].strip():
            options = webdriver.ChromeOptions()
            options.add_argument('--headless')
            options.add_argument('--no-sandbox')
            options.add_argument('--disable-dev-shm-usage')
            options.add_argument('--disable-gpu')
            
            driver = webdriver.Chrome(options=options)
            driver.get(url)

            power_cycles_button = driver.find_element(By.XPATH,"/html/body/div[2]/a[2]")
            power_cycles_button.click()
            time.sleep(2)
            
            rows = driver.find_elements(By.XPATH, "/html/body/div[2]/table[3]/tbody/tr")

            fail_count = 0
            for row in rows[1:]:  # skip header if row[0] is a header
                # loop_number = row.find_element(By.XPATH, "./td[1]").text
                loop_status = row.find_element(By.XPATH, "./td[2]").text
                if "Fail" in loop_status:
                    fail_count += 1
            driver.quit()
        data["fr"] = f"{fail_count}/{loop_count}"

    # Use the platform value if available.
    platform_value = platform[0].strip()
    
    # Mapping for programs that don't vary by platform.
    base_mapping = {
        "Strix1": "System-Strix1 FP8 APU",
        "Krackan1": "System-Krackan1 FP8 APU",
        "Krackan2e": "System-Krackan2e FP8 APU",
        "Strix Halo": "System-Strix Halo FP11 APU",
        "Medusa 1": "System-Medusa 1 FP10 APU",
        "Medusa 2": "System-Medusa 2 FP10 APU"
    }
    
    # For programs that need platform value differentiation.
    hawk_mapping = {
        "Hawk Point 1": {
            "BirmanPlus": "System-Hawk Point 1 FP8 APU",
            "Mayan": "System-Hawk Point 1 FP7 APU",
            "Lilac": "System-Hawk Point 1 FP7r2 APU"
        },
        "Hawk Point 2": {
            "BirmanPlus": "System-Hawk Point 2 FP8 APU",
            "Mayan": "System-Hawk Point 2 FP7 APU",
            "Lilac": "System-Hawk Point 2 FP7r2 APU"
        }
    }
    if data['program'] in base_mapping:
        data['system'] = base_mapping[data['program']]
    elif data['program'] in hawk_mapping:
        # Check if any of the keys appear in the platform_value.
        mapping = hawk_mapping[data['program']]
        found = False
        for key, sys_str in mapping.items():
            if key in platform_value:
                data['system'] = sys_str
                found = True
                break
        # If none of the expected keywords are found.
        if not found:
            data['system'] = f"System-{data['program']} Unknown"
    else:
        data['system'] = "Unknown System"

    return data

import os
import getpass
import json
import requests
from jira import JIRA
from aida_integ import read_data_from_aida, save_data_as_json
from scrutinizer_integ import read_scrutinizer_data
from requests.auth import HTTPBasicAuth
from lxml import html
from selenium import webdriver
from selenium.webdriver.common.by import By
import time

def valid_aida_url(url):
    if 'https://aida.amd.com/autodebug/' in url:
        return True
    else:
        print("Invalid AIDA URL")
        return False
    
def valid_scrutinizer_url(url):
    if 'http://scrutinizer.amd.com/' in url:
        return True
    else:
        print("Invalid Scrutinizer URL")
        return False
    
# Prompt for user credentials and URLs
username = input("Enter your AMD username: ")
password = getpass.getpass("Enter your AMD password: ")

# Prompt for AIDA URL until valid
while True:
    user_input = input("Enter your AIDA URL (or 'q' to quit): ")
    if user_input.lower() == 'q':
        print("Exiting program.")
        exit()  # or sys.exit()
    if valid_aida_url(user_input):
        url_aida = user_input
        break
    print("Please try again.")

# Prompt for Scrutinizer URL until valid
while True:
    url_scrutinizer = input("Enter your Scrutinizer URL (or 'q' to quit): ")
    if url_scrutinizer.lower() == 'q':
        print("Exiting program.")
        exit()
    if valid_scrutinizer_url(url_scrutinizer):
        break
    print("Please try again.")
                                                                                                                                        
# Read data from AIDA and Scrutinizer
issue_data_aida = read_data_from_aida(url_aida, username, password)
issue_data_scrutinizer = read_scrutinizer_data(url_scrutinizer)

if issue_data_aida:
    save_data_as_json(issue_data_aida, 'aida_data.json')
    print("Data saved as aida_data.json")
else:
    print("Failed to retrieve data from AIDA.")
    exit()

# Now, proceed with the auto-filer actions using the JSON file
server_url = 'https://ontrack-internal.amd.com'
jira = JIRA(server=server_url, basic_auth=(username, password))

# Load AIDA issue data from JSON
aida_json_path = 'aida_data.json'
if os.path.exists(aida_json_path):
    with open(aida_json_path, 'r') as f:
        issue_data_aida = json.load(f)
    print("Loaded AIDA data from JSON.")
else:
    print("AIDA JSON file not found.")
    exit()

# Define the issue details by filling in the fields from issue_data_aida and issue_data_scrutinizer
issue_dict = {
    'project': {'key': 'PLAT'},
    'issuetype': {'name': 'Issue'},
    'summary': '[' + issue_data_scrutinizer.get('program') + '] ' + issue_data_aida.get('summary')  + ' occured when ' + issue_data_scrutinizer.get('summary') + ', FR: ' + issue_data_scrutinizer.get('fr'),
    'description': issue_data_scrutinizer.get('description', '') + f"\nScrutinizer Link: {url_scrutinizer}\nAIDA Explanation: " + issue_data_aida.get('description', ''),
    'customfield_14308': 'Client - Platform Debug - HW', # Triage Assignment
    'customfield_14307': 'APU', # Triage Category
    'customfield_12610': {'value': 'Medium'}, #Severity
    'customfield_13002': issue_data_scrutinizer.get('program'),  # Program
    'customfield_13208': issue_data_scrutinizer.get('system'),  # System
    'customfield_14200': issue_data_scrutinizer.get('bios'),  # BIOS Version
    'customfield_17000': issue_data_scrutinizer.get('revision'), # Silicon-Die Revision
    'customfield_11607': issue_data_scrutinizer.get('steps_to_reproduce'),  # Steps to Reproduce
}
print(issue_dict) #for testing purposes
# Create a new JIRA issue using the issue dictionary.
# new_issue = jira.create_issue(fields=issue_dict)
# print(f"Issue {new_issue.key} created successfully.")

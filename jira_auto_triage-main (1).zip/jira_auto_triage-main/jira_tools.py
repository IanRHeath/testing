import os
from langchain.tools import tool
from typing import List, Dict, Any, Optional
from jira import JIRA
from jira_utils import search_jira_issues, get_ticket_details, initialize_jira_client, create_jira_issue, JiraBotError
from jql_builder import (
    extract_params, build_jql, program_map, system_map,
    VALID_SILICON_REVISIONS, VALID_TRIAGE_CATEGORIES, triage_assignment_map,
    VALID_SEVERITY_LEVELS
)
from llm_config import get_llm

JIRA_CLIENT_INSTANCE = None
try:
    JIRA_CLIENT_INSTANCE = initialize_jira_client()
except JiraBotError as e:
    print(f"CRITICAL ERROR: Could not initialize JIRA client at startup. Tools will not work: {e}")

def _get_single_ticket_summary(issue_key: str, question: str) -> str:
    """Internal helper to get a summary for one ticket, tailored to a specific question."""
    if JIRA_CLIENT_INSTANCE is None:
        raise JiraBotError("JIRA client not initialized.")
    sanitized_key = issue_key.replace('_', '-').upper()
    print(f"Generating summary for {sanitized_key} based on question: '{question}'...")
    details_text, ticket_url = get_ticket_details(sanitized_key, JIRA_CLIENT_INSTANCE)
    llm = get_llm()
    prompt = f"""
    You are an expert engineering assistant. Your task is to answer a user's question based on the provided 'Ticket Details'.

    **User's Question:** "{question}"
    **Ticket Details:**
    ---
    {details_text}
    ---

    **Instructions:**
    1.  Begin your answer *always* with the ticket key and the link, like this: `Summary for PLAT-123: [Link]`
    2.  Then, analyze the "User's Question".
    3.  If the question is a generic request for a "full summary", "summary", "details", or similar, provide a detailed, structured summary with these four points: Problem Statement, Latest Analysis / Debug, Identified Root Cause, and Current Blockers.
    4.  If the question is specific (e.g., "what is the root cause?", "who is assigned?", "what are the blockers?"), provide a direct, concise answer to only that question.
    5.  If the question implies an audience (e.g., "for a manager"), tailor the summary's content and tone appropriately, focusing on status, impact, and blockers.

    **Answer:**
    """
    summary_content = llm.invoke(prompt).content
    final_output = f"Summary for {sanitized_key}: {ticket_url}\n\n{summary_content}"
    return final_output

@tool
def get_field_options_tool(field_name: str, depends_on: Optional[str] = None) -> str:
    """
    Use this tool when the user asks for the available or valid options for a specific ticket field, such as 'Triage Category', 'Program', 'System', or 'Triage Assignment'.
    For dependent fields like 'System' or 'Triage Assignment', the 'depends_on' parameter must be provided with the parent field's value.
    """
    field_lower = field_name.lower()
    if "program" in field_lower:
        return f"The valid options for Program are: {list(program_map.keys())}"
    elif "triage category" in field_lower:
        return f"The valid options for Triage Category are: {list(VALID_TRIAGE_CATEGORIES)}"
    elif "silicon revision" in field_lower:
        return f"The valid options for Silicon Revision are: {list(VALID_SILICON_REVISIONS)}"
    elif "severity" in field_lower:
        return f"The valid options for Severity are: {list(VALID_SEVERITY_LEVELS)}"
    elif "system" in field_lower:
        if not depends_on:
            return "To list the valid Systems, you must first provide a Program code."
        options = system_map.get(depends_on.upper())
        if options:
            return f"For Program '{depends_on.upper()}', the valid Systems are: {options}"
        else:
            return f"Could not find a Program with the code '{depends_on.upper()}'."
    elif "triage assignment" in field_lower:
        if not depends_on:
            return "To list the Triage Assignments, you must first provide a Triage Category."
        options = triage_assignment_map.get(depends_on.upper())
        if options:
            return f"For Triage Category '{depends_on.upper()}', the valid Triage Assignments are: {options}"
        else:
            return f"Could not find a Triage Category named '{depends_on.upper()}'."
    
    return f"Sorry, I cannot provide options for the field '{field_name}'."

@tool
def create_ticket_tool(summary: str, issuetype: str, program: str, system: str, silicon_revision: str, bios_version: str, triage_category: str, triage_assignment: str, severity: str, project: str = "PLATFORM") -> str:
    """
    Use this tool to create a new Jira ticket. It gathers structured fields, then interactively prompts the user to complete a detailed template for the description and steps to reproduce.
    """
    if JIRA_CLIENT_INSTANCE is None:
        raise JiraBotError("JIRA client not initialized.")

    valid_issue_types = ['Issue', 'enhancement', 'draft']
    if issuetype.lower() not in [t.lower() for t in valid_issue_types]:
        return f"Error: Invalid issue type '{issuetype}'. It must be one of {valid_issue_types}."
    program_code = program.upper()
    if program_code not in program_map:
        return f"Error: Invalid program code '{program}'. It must be one of {list(program_map.keys())}."
    valid_systems = system_map.get(program_code)
    if not valid_systems or system not in valid_systems:
        return f"Error: Invalid system '{system}' for program '{program_code}'. Valid options are: {valid_systems}"
    if silicon_revision.upper() not in VALID_SILICON_REVISIONS:
        return f"Error: Invalid silicon revision '{silicon_revision}'. Please provide a valid option."
    triage_cat_upper = triage_category.upper()
    if triage_cat_upper not in VALID_TRIAGE_CATEGORIES:
        return f"Error: Invalid triage category '{triage_category}'. It must be one of {list(VALID_TRIAGE_CATEGORIES)}."
    valid_assignments = triage_assignment_map.get(triage_cat_upper)
    if not valid_assignments or triage_assignment not in valid_assignments:
        return f"Error: Invalid triage assignment '{triage_assignment}' for category '{triage_cat_upper}'. Valid options are: {valid_assignments}"
    severity_title = severity.title()
    if severity_title not in VALID_SEVERITY_LEVELS:
        return f"Error: Invalid severity '{severity}'. It must be one of {list(VALID_SEVERITY_LEVELS)}."

    program_full_name = program_map[program_code]

    steps_delimiter = "\n\n---STEPS-TO-REPRODUCE---\n"
    description_template = f"""---DESCRIPTION---
Detailed Summary:

System Level Signature:

Failure Rate:

Additional Information:

SUT Configuration:

Board details / revision: {system}
OS version:
GFX driver version:
Chipset:
BIOS Ver: {bios_version}
BIOS Edits:
OS Edits:
All external devices connected:

Regression Details: 

Link to Test Case:

Expected behavior:

Actual Behavior:

All Scandump Links:
{steps_delimiter}(Please provide detailed steps to reproduce the issue below this line)
"""
    description_filename = "ticket_description.txt"
    try:
        with open(description_filename, "w") as f:
            f.write(description_template)
        
        print("\n----------------------------------------------------------------")
        print(f"ACTION REQUIRED: I have created a template file named '{description_filename}' in this directory.")
        print("Please open the file, fill in the Description and Steps to Reproduce, and save it.")
        input("Press Enter here when you have saved the file and are ready to continue...")
        
        with open(description_filename, "r") as f:
            full_text_input = f.read()
            
    finally:
        if os.path.exists(description_filename):
            os.remove(description_filename)
    
    if steps_delimiter in full_text_input:
        description_part, steps_part = full_text_input.split(steps_delimiter, 1)
        final_description = description_part.replace("---DESCRIPTION---", "").strip()
        final_steps = steps_part.strip()
    else:
        final_description = full_text_input.replace("---DESCRIPTION---", "").strip()
        final_steps = "Not provided."

    print("\n---")
    print("A new Jira ticket will be created with the following details:")
    print(f"  Project:           {project}")
    print(f"  Issue Type:        {issuetype}")
    print(f"  Severity:          {severity_title}")
    print(f"  Triage Category:   {triage_cat_upper}")
    print(f"  Triage Assignment: {triage_assignment}")
    print(f"  Program:           {program_full_name}")
    print(f"  System:            {system}")
    print(f"  Silicon Revision:  {silicon_revision.upper()}")
    print(f"  BIOS Version:      {bios_version}")
    print(f"  Summary:           {summary}")
    print("\n--- Description Preview ---")
    print(final_description)
    print("\n--- Steps to Reproduce Preview ---")
    print(final_steps)
    print("----------------------------------\n")
    
    confirmation = input("Is this information correct? (yes/no): ")

    if confirmation.lower().strip() != 'yes':
        return "Ticket creation cancelled by user."

    try:
        new_issue = create_jira_issue(
            client=JIRA_CLIENT_INSTANCE, project=project, summary=summary, description=final_description,
            issuetype=issuetype, program=program_full_name, system=system, silicon_revision=silicon_revision.upper(),
            bios_version=bios_version, triage_category=triage_cat_upper, triage_assignment=triage_assignment,
            severity=severity_title, steps_to_reproduce=final_steps
        )
        return f"Successfully created ticket {new_issue.key}. You can view it here: {new_issue.permalink()}"
    except JiraBotError as e:
        return str(e)


@tool
def summarize_ticket_tool(issue_key: str, question: Optional[str] = "Provide a full 4-point summary.") -> str:
    """Use this tool to summarize a SINGLE JIRA ticket OR to get its URL."""
    return _get_single_ticket_summary(issue_key, question)

@tool
def summarize_multiple_tickets_tool(issue_keys: List[str]) -> str:
    """Use this tool when the user asks to summarize MORE THAN ONE JIRA ticket."""
    summaries = []
    question_for_each = "Provide a full 4-point summary."
    for key in issue_keys:
        try:
            summaries.append(_get_single_ticket_summary(key, question_for_each))
        except JiraBotError as e:
            summaries.append(f"Could not generate summary for {key}: {e}")
    return "\n\n---\n\n".join(summaries)

@tool
def jira_search_tool(query: str) -> List[Dict[str, Any]]:
    """Searches JIRA issues based on a natural language query."""
    if JIRA_CLIENT_INSTANCE is None: raise JiraBotError("JIRA client not initialized.")
    try:
        params = extract_params(query)
        limit = int(params.get("maxResults", 20))
        jql_query = build_jql(params)
        return search_jira_issues(jql_query, JIRA_CLIENT_INSTANCE, limit=limit)
    except JiraBotError as e:
        raise e
    except Exception as e:
        raise JiraBotError(f"An unexpected error occurred in jira_search_tool: {e}")

ALL_JIRA_TOOLS = [
    jira_search_tool,
    summarize_ticket_tool,
    summarize_multiple_tickets_tool,
    create_ticket_tool,
    get_field_options_tool
]

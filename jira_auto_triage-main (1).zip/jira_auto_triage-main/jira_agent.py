import sys
from langchain.agents import AgentExecutor, create_tool_calling_agent
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.language_models.chat_models import BaseChatModel
from llm_config import get_llm
from jira_tools import ALL_JIRA_TOOLS
from jira_utils import JiraBotError

def get_jira_agent() -> AgentExecutor:
    llm = get_llm()

    system_message = """
    You are a helpful JIRA assistant. Your job is to understand the user's request and use the provided tools to fulfill it.

    **Your Capabilities:**
    - You can search for JIRA tickets.
    - You can summarize one or more JIRA tickets.
    - You can create new JIRA tickets.
    - You can list the available options for ticket fields.

    **Behavioral Guidelines:**
    - Your primary goal is to select the correct tool for the job.
    - If the user wants to create a ticket, you must gather all the required structured information before calling the creation tool. This includes: summary, issue type, program, system, silicon revision, BIOS version, severity, and triage category.
    - The 'triage assignment' and 'system' fields depend on their parent fields. You may need to ask for the parent field first.
    - If a user's request is ambiguous, ask for clarification.
    """

    prompt = ChatPromptTemplate.from_messages(
        [
            ("system", system_message),
            MessagesPlaceholder(variable_name="chat_history", optional=True),
            ("human", "{input}"),
            MessagesPlaceholder(variable_name="agent_scratchpad"),
        ]
    )

    agent = create_tool_calling_agent(llm, ALL_JIRA_TOOLS, prompt)

    agent_executor = AgentExecutor(
        agent=agent,
        tools=ALL_JIRA_TOOLS,
        verbose=False,
        handle_parsing_errors=True,
        max_iterations=20,
        return_intermediate_steps=True
    )
    print("LangChain Agent initialized successfully.")
    return agent_executor

# Jira Triage LLM Agent

This project is a Python-based, command-line application that uses a Large Language Model (LLM) to interact with a Jira instance through natural language. It allows users to search for tickets and get intelligent, context-aware summaries without writing JQL.

## Features

This section covers the agent's current capabilities as well as features on the project roadmap.

### Current Capabilities

* **Advanced Ticket Searching**
    * **Natural Language Queries:** Search for tickets using plain English (e.g., "my open bugs") instead of JQL.
    * **Result Limiting:** Specify the number of results you want to see (e.g., "find the 5 latest tickets").
    * **Criteria Filtering:** Understands key criteria like `project`, `priority`, and `program`.

* **Intelligent Ticket Summarization**
    * **Structured Summaries:** Get a detailed 4-point engineering summary for any ticket, covering the problem statement, latest analysis, root cause, and blockers.
    * **Multi-Ticket Reports:** Request summaries for multiple tickets in a single command and receive a consolidated report.
    * **Context-Aware Q&A:** Ask specific questions about a ticket (e.g., "who is assigned?") and get a direct, concise answer.

### Planned Features

The following features are on the project roadmap to fully realize the "End-to-End Auto-Triage" vision outlined in the project diagram:

* **Ticket Creation:** The ability to create new Jira tickets (Bugs, Tasks, etc.) directly from a natural language command.
* **Duplicate Ticket Detection:** Before creating a new ticket, the agent will automatically search for similar existing issues to prevent duplicates.
* **Guideline Validation:** The ability to check if a new ticket's description meets team guidelines for quality and completeness before it's created.

## Setup and Installation

Follow these steps to set up and run the project on your local machine.

### Prerequisites

* Python 3.8+

### Installation

1.  **Clone the repository** (or ensure all project files are in a single directory).

2.  **Create and activate a virtual environment.** This is highly recommended to keep dependencies isolated.
    ```bash
    # Create the virtual environment
    python -m venv venv

    # Activate it (on Windows)
    .\venv\Scripts\activate

    # Activate it (on macOS/Linux)
    source venv/bin/activate
    ```

3.  **Install the required dependencies.** Create a file named `requirements.txt` in the project's root directory and add the following lines to it:
    ```text
    langchain
    langchain-openai
    python-dotenv
    jira
    openai
    ```
    Then, install them using `pip`:
    ```bash
    pip install -r requirements.txt
    ```

### Configuration

The agent requires credentials for both your Jira instance and the LLM API (Azure OpenAI).

1.  Create a file named `.env` in the root directory of the project.

2.  Copy and paste the following template into the `.env` file and fill in your specific values.

    ```env
    # JIRA Configuration
    JIRA_SERVER_URL="[https://ontrack-internal.amd.com/](https://ontrack-internal.amd.com/)"
    JIRA_USERNAME="your-jira-email@example.com"
    JIRA_PASSWORD="your_jira_api_token"

    # Azure OpenAI LLM Configuration
    LLM_API_KEY="your_azure_openai_api_key"
    LLM_API_VERSION="your_api_version"
    LLM_RESOURCE_ENDPOINT="[https://your-resource.openai.azure.com/](https://your-resource.openai.azure.com/)"
    LLM_CHAT_DEPLOYMENT_NAME="your_deployment_name"
    ```
## How to Run

Once the setup and configuration are complete, you can start the agent by running `main.py` from your terminal:

```bash
python main.py
```
The application will initialize and prompt you for your request. To exit, simply type exit.

### Usage Examples
Here are some examples of how to interact with the bot:

### Searching for Tickets
* show me the 3 latest P1 tickets

* find tickets assigned to me

### Getting a Full Summary of a Single Ticket
* summarize PLAT-177493

* give me the details for PLAT-177489

### Asking a Specific Question about a Ticket
* what is the root cause of PLAT-177493?

* who is assigned to PLAT-177489?

### Summarizing Multiple Tickets at Once
* summarize PLAT-177493 and PLAT-177489

* can I get summaries for PLAT-173036, PLAT-171065, and PLAT-171053?

### Project Structure
```bash
.
├── .env                # Stores all your secret keys and configurations
├── jira_agent.py       # Defines the LangChain agent and its core prompt
├── jira_tools.py       # Contains all the tools the agent can use (search, summarize)
├── jira_utils.py       # Handles direct communication with the Jira API
├── jql_builder.py      # Logic for converting natural language into a JQL query
├── llm_config.py       # Configures the connection to the Azure OpenAI LLM
├── main.py             # The main entry point to run the application
└── requirements.txt    # Lists all the Python dependencies for the project
